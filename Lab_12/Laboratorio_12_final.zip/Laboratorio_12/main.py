from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import pickle
import os
import pandas as pd

# Definir la aplicación FastAPI
app = FastAPI()

# Cargar el modelo entrenado
model_path = "models/best_model.pkl"
if os.path.exists(model_path):
    with open(model_path, "rb") as f:
        model = pickle.load(f)
else:
    raise FileNotFoundError(f"Model file not found at {model_path}")

# Definir el modelo de entrada para el endpoint de predicción
class WaterQuality(BaseModel):
    ph: float
    Hardness: float
    Solids: float
    Chloramines: float
    Sulfate: float
    Conductivity: float
    Organic_carbon: float
    Trihalomethanes: float
    Turbidity: float

# Ruta home que describe el modelo
@app.get("/")
def read_root():
    return {
        "model": "XGBoost regressor for water potability prediction",
        "description": "This model predicts whether a water sample is potable based on various chemical properties.",
        "input": {
            "ph": "float",
            "Hardness": "float",
            "Solids": "float",
            "Chloramines": "float",
            "Sulfate": "float",
            "Conductivity": "float",
            "Organic_carbon": "float",
            "Trihalomethanes": "float",
            "Turbidity": "float"
        },
        "output": {
            "potability": "int (0 for non-potable, 1 for potable)"
        }
    }

# Ruta POST para predecir la potabilidad del agua
@app.post("/potability/")
def predict_potability(data: WaterQuality):
    try:
        # Convertir la entrada a DataFrame
        input_data = pd.DataFrame([data.dict()])
        
        # Hacer la predicción
        prediction = model.predict(input_data)
        
        # Devolver la predicción en formato JSON
        return {"potabilidad": int(prediction[0])}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)